<?php

/**
 * WHMCS Price Integration
 * 
 * @author            Astral Internet inc.
 * @copyright         2021 Copyright (C) 2021, Astral Internet inc. - support@astralinternet.com
 * @license           http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License, version 3 or higher
 * 
 * @wordpress-plugin
 * Plugin Name: 		WHMCS Price Integration
 * Plugin URI:      	https://github.com/AstralInternet/WHMCS-Price-Integration
 * Description:			Provide the ability to add WHMCS prices directly inside a WordPress page using the WHMCS API and WordPRess Gutenberg block.
 * Version:         	0.1
 * Author:				Astral Internet inc.
 * Author URI:			https://www.astralinternet.com/fr
 * License:				GPL v3
 * License URI:			http://www.gnu.org/licenses/gpl-3.0.html
 * Text Domain: 		whmcs-pi
 * Domain Path:     	/i18n
 * Requires at least:	5.0.0
 * Requires PHP:		7.2
 *
 * Available shortcode : 
 * [whmcs_domainscat tld="com" bypasscache='true"]
 * [whmcs_domainsprice tld="com" bypasscache='true"]
 * [whmcs_domainspromo tld="com" bypasscache='true"]
 * [whmcs_domainsflag tld="com" bypasscache='true"]
 */


/**
 * Function to return a domain category
 *
 * The available params are : 
 *   tld : the domain TLD
 *   bypasscache (default false): Bypass the cache of one hour. The cache is there to prevent overloading the WHMCS server
 */
function whmcs_domainscat_func($p_atts)
{
    // Parse the given attributes
    $attribute = shortcode_atts(array(
        'tld' => '',
        'bypasscache' => false
    ), $p_atts);

    // Validate the TLD
    if (empty($attribute['tld'])) {
        $msg = __("TLD cannot be empty.", "whmcs-pi");
        $msg = whmcs_products_func_prepareOutput($msg, '', '', '', true);
        return $msg;
    }

    // Clean boolean
    $attribute['bypasscache'] =  boolval('bypasscache');

    // Initiate the product class
    $domainObj = WHMCS_PI_Main::load_domain_class();

    // Fetch the tld Information
    $tldDetail = $domainObj->Get_TLD_Detail($attribute['tld']);

    // return the TLD category
    return $tldDetail['categories'][0];
}

/**
 * Register the WHMCS Shortcode function
 */
add_shortcode('whmcs_domainscat', 'whmcs_domainscat_func');

/**
 * Function to return a domain flag
 *
 * The available params are : 
 *   tld : the domain TLD
 *   bypasscache (default false): Bypass the cache of one hour. The cache is there to prevent overloading the WHMCS server
 */
function whmcs_domainsflag_func($p_atts)
{
    // Parse the given attributes
    $attribute = shortcode_atts(array(
        'tld' => '',
        'bypasscache' => false
    ), $p_atts);

    // Validate the TLD
    if (empty($attribute['tld'])) {
        $msg = __("TLD cannot be empty.", "whmcs-pi");
        $msg = whmcs_products_func_prepareOutput($msg, '', '', '', true);
        return $msg;
    }

    // Clean boolean
    $attribute['bypasscache'] =  boolval('bypasscache');

    // Initiate the product class
    $domainObj = WHMCS_PI_Main::load_domain_class();

    // Fetch the tld Information
    $tldDetail = $domainObj->Get_TLD_Detail($attribute['tld']);

    // return the TLD flag
    return $tldDetail['flag'];
}

/**
 * Register the WHMCS Shortcode function
 */
add_shortcode('whmcs_domainsflag', 'whmcs_domainsflag_func');

/**
 * Function to return a domain price
 *
 * The available params are : 
 *   tld : the domain TLD
 *   bypasscache (default false): Bypass the cache of one hour. The cache is there to prevent overloading the WHMCS server
 */
function whmcs_domainsprice_func($p_atts)
{
    // Parse the given attributes
    $attribute = shortcode_atts(array(
        'tld' => '',
        'bypasscache' => false
    ), $p_atts);

    // Validate the TLD
    if (empty($attribute['tld'])) {
        $msg = __("TLD cannot be empty.", "whmcs-pi");
        $msg = whmcs_products_func_prepareOutput($msg, '', '', '', true);
        return $msg;
    }

    // Clean boolean
    $attribute['bypasscache'] =  boolval('bypasscache');

    // Initiate the product class
    $domainObj = WHMCS_PI_Main::load_domain_class();

    // Fetch the tld Information
    $tldDetail = $domainObj->Get_TLD_Detail($attribute['tld']);

    // return the TLD price
    return $tldDetail['reg_price'];
}

/**
 * Register the WHMCS Shortcode function
 */
add_shortcode('whmcs_domainsprice', 'whmcs_domainsprice_func');

/**
 * Function to return a domain promo price
 *
 * The available params are : 
 *   tld : the domain TLD
 *   bypasscache (default false): Bypass the cache of one hour. The cache is there to prevent overloading the WHMCS server
 */
function whmcs_domainspromo_func($p_atts)
{
    // Parse the given attributes
    $attribute = shortcode_atts(array(
        'tld' => '',
        'bypasscache' => false
    ), $p_atts);

    // Validate the TLD
    if (empty($attribute['tld'])) {
        $msg = __("TLD cannot be empty.", "whmcs-pi");
        $msg = whmcs_products_func_prepareOutput($msg, '', '', '', true);
        return $msg;
    }

    // Clean boolean
    $attribute['bypasscache'] =  boolval('bypasscache');

    // Initiate the product class
    $domainObj = WHMCS_PI_Main::load_domain_class();

    // Fetch the tld Information
    $tldDetail = $domainObj->Get_TLD_Detail($attribute['tld']);

    // return the TLD promo price
    return $tldDetail['promo'];
}

/**
 * Register the WHMCS Shortcode function
 */
add_shortcode('whmcs_domainspromo', 'whmcs_domainspromo_func');


/**
 * Function to return a formated view of each domain and it corresponding categorie
 *
 * The available params are : 
 *   bypasscache (default false): Bypass the cache of one hour. The cache is there to prevent overloading the WHMCS server
 */
function whmcs_domainsdisplayall_func($p_atts)
{

    // Parse the given attributes
    $attribute = shortcode_atts(array(
        'bypasscache' => false
    ), $p_atts);

    // Initiate the product class
    $domainObj = WHMCS_PI_Main::load_domain_class();

    // Fetch the tld Information
    $allTldDetail = $domainObj->Get_Whmcs_TLD_List($attribute['bypasscache']);

    // Temp return result
    $rtn = "<pre>";
    $rtn .= print_r($allTldDetail, true);
    $rtn .= "</pre>";

    // Build the category list
    $htmlCategoryList = whmcs_TLD_Category_To_HTML_Ul($allTldDetail);

    // Build a table
    $htmlTable = '<table id="tldgroup"><tbody>';

    // Go through each TLD
    foreach ($allTldDetail['tlddetail'] as $tldName => $tldDetail) {

        $trClass = 'all ' . $tldDetail['flag'];

        // Build the TLD class for the TR element
        foreach ($tldDetail['categories'] as $category) {
            $trClass .= ' ' . str_replace(" ", "_", $category);
        }

        // Open the row
        $htmlTR = '<tr data-tldname="' . $tldName . '" class="'.$trClass.'">';

        // Add the TLD column
        $htmlTR .= '<td class="table_tld">'.$tldName.'</td>';

        // Add the price and buy column
        $htmlTR .= '<td class="table_tld_cart">';

        // Close the cart column
        $htmlTR .= '</td>';

        // Close the row
        $htmlTR .= '</tr>';

        //Append the row to the table
        $htmlTable .= $htmlTR;
    }

    // Close HTML Table
    $htmlTable .= '</tbody></table>';

    // return the TLD display
    return $htmlTable;
}

/**
 * Register the WHMCS Shortcode function
 */
add_shortcode('whmcs_domainsdisplayall', 'whmcs_domainsdisplayall_func');



########################
### HELPER FUNCTIONS ###
########################

/**
 * Build a HTML list of all the TLD category from WHMCS
 * 
 * @since 1.0.0
 * @param array list of all WHMCS TLD detail
 * @return string (HTML UL block)
 */
function whmcs_TLD_Category_To_HTML_Ul($p_allTldDetail)
{

    // Build the category list
    $htmlList = '<ul id="whmcs_tld_categories_list">';

    // Go through each categorie
    foreach ($p_allTldDetail['categories'] as $tldGroup => $groupTLDs) {

        // Prepare HTML LI class; Select "all" by default
        if ($tldGroup == 'all') {
            $class = 'class="selected" ';
        } else {
            $class = '';
        }

        // replace space by "_" ffrom the tld group for the HTML LI data attribute
        $htmlTldgroup = str_replace(" ", "_", $tldGroup);

        // Build the LI element
        $htmlLI =  '<li ' . $class . 'data-tldgroup="' . $htmlTldgroup . '">' . __($tldGroup, "whmcs-pi-tld-group") . ' (' . count($groupTLDs) . ')</li>';

        // Add HTML LI to the UL element
        $htmlList .= $htmlLI;
    }

    // Close the category list
    $htmlList .= '</ul>';

    // Return the HTML UL List
    return $htmlList;
}
